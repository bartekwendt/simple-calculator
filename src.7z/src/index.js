import React from 'react'
import ReactDOM from 'react-dom'
import './style.css'

import CalcMain from './components/CalcMain'


function App(){
  return(
    <div>
      <CalcMain />
    </div>
  )
}


ReactDOM.render(
  <App />,
  document.getElementById('root')
)
