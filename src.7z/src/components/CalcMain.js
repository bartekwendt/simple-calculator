import React from 'react'

function CalcMain(){
  return(
    <div className="CalcWrapper">
      <div className="ResultPlaceholder">
        <p className="ResultEqual">=</p>
        <p className="ResultOutput">135 242</p>
      </div>

      <div className="SpanRow">
        <span className="CalcKey OperationButton ClearButton">C</span>
        <span className="CalcKey OperationButton">P</span>
        <span className="CalcKey OperationButton">%</span>
        <span className="CalcKey OperationButton">&#247;</span>
      </div>

      <div className="SpanRow">
        <span className="CalcKey">7</span>
        <span className="CalcKey">8</span>
        <span className="CalcKey">9</span>
        <span className="CalcKey OperationButton">x</span>
      </div>

      <div className="SpanRow">
        <span className="CalcKey">4</span>
        <span className="CalcKey">5</span>
        <span className="CalcKey">6</span>
        <span className="CalcKey OperationButton">-</span>
      </div>

      <div className="SpanRow">
        <span className="CalcKey">1</span>
        <span className="CalcKey">2</span>
        <span className="CalcKey">3</span>
        <span className="CalcKey OperationButton">+</span>
      </div>

      <div className="SpanRow">
        <span className="CalcKey">0</span>
        <span className="CalcKey">.</span>
        <span className="CalcKey">&#8617;</span>
        <span className="CalcKey OperationButton EqualButton">=</span>
      </div>

    </div>
  )
}

export default CalcMain
